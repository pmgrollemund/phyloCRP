cmd <- "sh inst/after_check"
system(cmd)
