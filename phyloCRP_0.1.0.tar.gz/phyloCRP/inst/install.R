cmd <- "sh inst/install"
system(cmd)
